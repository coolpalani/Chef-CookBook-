bash 'extract_module' do
code <<-EOH
cd /etc/yum.repos.d/
echo "Enabling the repos"
pwd
sed -i 's/enabled=0/enabled=1/g' *.repo
echo "Enabling the repo done..."
yum install -y wget tar
#Adding the Jenkins Repo
wget -O /etc/yum.repos.d/jenkins.repo http://pkg.jenkins.io/redhat-stable/jenkins.repo
rpm --import http://pkg.jenkins.io/redhat-stable/jenkins.io.key
echo "Done Adding the jenkins Repo...."
#Installing the OpenJDK 8 for Linux REHL 7
echo "Installing the openjdk package.."
yum install -y java-1.8.0-openjdk-devel
echo "Done Installing the OPENJDK......"
#Installing Jenkins
echo "Installing the Jenkins...."
yum install -y jenkins
echo "Jenkins Continuous Integration Server Installed...."
#Starting the Jenkins Services....
echo "Stating the Jenkins Services...."
service jenkins start
echo "Jenkins Started Sucessfully....."
EOH
end
