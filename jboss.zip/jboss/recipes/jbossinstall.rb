cookbook_file "/tmp/jbossinstall.sh" do
  source "jbossinstall.sh"
      mode 0777
          end

	      execute "install my lib" do
	            command "sh /tmp/jbossinstall.sh"
		          end
