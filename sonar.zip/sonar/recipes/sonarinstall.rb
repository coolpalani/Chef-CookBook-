cookbook_file "/tmp/sonar.sh" do
  source "sonar.sh"
    mode 0777
    end

    execute "install my lib" do
      command "sh /tmp/sonar.sh"
      end
